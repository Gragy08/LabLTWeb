<html>
<head>
<title>Declaring a Function</title>
</head>
<body>
<?php

function bighello(){
     print "<h1>HELLO!</h1>";
}

bighello();

?>
 </body>
</html>