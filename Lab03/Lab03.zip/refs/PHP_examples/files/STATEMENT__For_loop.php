<?php
   // Example Two
   for ($kilometers = 1; ; $kilometers++) {
      if ($kilometers > 5) break;
         echo "$kilometers kilometers = ".$kilometers*0.62140. " miles. <br />";
   }
?>