<?
    $nIndex = 17;
    switch ( $nIndex )
    {
        case 0:
            print( "zero<br>" );
            break;
        case 1:
            print( "one<br>" );
            break;
        case 2:
            print( "two<br>" );
            break;
        default:
            print( "neither zero, one nor two<br>" );
            break;
    }
?>