<?php
print ucfirst("how do you do today?");
print("<br />");
print ucwords("the prince of wales");
?>