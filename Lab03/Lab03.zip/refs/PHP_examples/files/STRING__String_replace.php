<?php

    $haystack = 'this is a test';

    $newstr = str_replace ('is', 'is not', $haystack); 

    echo "$newstr\n";

?>