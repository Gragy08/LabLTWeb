<?
    $string = "I like to program in PHP";
    $a = strtolower($string);
    echo $a;
?>